-- CollectionLog_Data_Core.lua
local ADDON, ns = ...

-- Core pack is reserved for shared/core definitions.
-- Placeholders have been removed.
ns.RegisterPack("core", {
  version = 1,
  groups = {
    -- intentionally empty
  }
})
