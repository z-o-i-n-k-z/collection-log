-- Auto-generated placeholder pack file
-- Raids - The War Within
local pack = {
  version = 1,
  id = "raids_tww",
  expansion = "The War Within",
  category = "Raids",
  groups = {},
}
CollectionLog_DataPacks = CollectionLog_DataPacks or {}
CollectionLog_DataPacks["raids_tww"] = pack
