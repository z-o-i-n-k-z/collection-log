-- Auto-generated CollectionLog_Data packs
CollectionLog_DataPacks = CollectionLog_DataPacks or {}
