-- Auto-generated placeholder pack file
-- Dungeons - The War Within
local pack = {
  version = 1,
  id = "dungeons_tww",
  expansion = "The War Within",
  category = "Dungeons",
  groups = {},
}
CollectionLog_DataPacks = CollectionLog_DataPacks or {}
CollectionLog_DataPacks["dungeons_tww"] = pack
